import matplotlib.pyplot as plt

def ParallelBar(x_labels, y, labels=None, colors=None, width = 0.35, gap=2):
    '''
    绘制并排柱状图
    :param x_labels: list 横坐标刻度标识
    :param y: list 列表里每个小列表是一个系列的柱状图
    :param labels: list 每个柱状图的标签
    :param colors: list 每个柱状图颜色
    :param width: float 每条柱子的宽度
    :param gap: int 柱子与柱子间的宽度
    '''

    # check params
    if labels is not None:
        if len(labels) < len(y): raise ValueError('labels的数目不足')
    if colors is not None:
        if len(colors) < len(y): raise ValueError('颜色colors的数目不足')
    if not isinstance(gap, int): raise ValueError('输入的gap必须为整数')

    x = [t for t in range(0, len(x_labels)*gap, gap)]  # the label locations
    fig, ax = plt.subplots()
    for i in range(len(y)):
        if labels is not None: l = labels[i]
        else: l = None
        if colors is not None: color = colors[i]
        else: color = None
        if len(x) != len(y[i]): raise ValueError('所给数据数目与横坐标刻度数目不符')
        plt.bar(x, y[i], label=l, width=width, color=color,edgecolor='black', linewidth=0.5)
        x = [t+width for t in x]
    x = [t + (len(y)-1)*width/2 for t in range(0, len(x_labels) * gap, gap)]
    ax.set_xticks(x)
    ax.set_xticklabels(x_labels)

# x_labels = ['a', 'b', 'c', 'd', 'e']

# y = [[1,2,3,4,5],[5,4,3,2,1],[1,2,3,2,1]]
# labels = ['A', 'B', 'C','D']

labels = ['SMOTE','RUS','ROS','ENN','ADASYN']

metrics = ['SN', 'MCC', 'ACC', 'PE', 'SP', 'AUC']
# colors = ['b', 'g', 'r', 'c', 'm', 'y']
# colors = ['#8ECFC9', '#FFBE7A', '#FA7F6F', '#82B0D2', '#BEB8DC', '#E7DAD2']
# colors = ['#F27970', '#BB9727', '#54B345', '#32B897', '#05B9E2', '#8983BF', '#C76DA2']
colors = ['#A1A9D0', '#F0988C', '#B883D4', '#9E9E9E', '#CFEAF1', '#C4A5DE', '#F6CAE5', '#96CCCB']



data = [
    [0.5611, 0.4661, 0.8461, 0.5576, 0.9061, 0.8538],
    [0.7461, 0.4716, 0.8024, 0.4586, 0.8143, 0.8576],
    [0.3699, 0.4191, 0.8564, 0.6556, 0.959, 0.8575],
    [0.6708, 0.4998, 0.8395, 0.531, 0.8751, 0.8525],
    [0.5705, 0.4558, 0.8395, 0.5369, 0.8962, 0.8516]
]


ParallelBar(metrics, data, labels=labels, colors=colors, width=0.15, gap=1)
# font3 = {'family' : 'Arial',
#          'weight' : 'normal'}
plt.ylim(0, 1.1)
plt.legend(frameon=True,loc="upper left",fontsize='small') #分别为图例无边框、图例放在右上角、图例大小


plt.tight_layout()
plt.savefig('Figure2.tif', dpi=1200)

plt.show()
