import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

# 构造数据
import numpy as np
import time
import scipy.io as scio
from imblearn.over_sampling import SMOTE, RandomOverSampler
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import confusion_matrix, accuracy_score, matthews_corrcoef, roc_auc_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from imblearn.over_sampling import ADASYN
from imblearn.under_sampling import EditedNearestNeighbours

import xgboost as xgb



def scale_dataset(X_train, X_test):
    scaler = MinMaxScaler().fit(X_train)
    X_train_scaled = scaler.transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled


# 取数据集
dataset = scio.loadmat("./Dataset_vesicular_9787_1832.mat")
dataset_reAATP = scio.loadmat("./Dataset_vesicular_reAATP_9787_1832.mat")
# print(dataset)

# 420
AATP_9787 = dataset['AATP_9787']
AATP_1832 = dataset['AATP_1832']
# 150
GE_9787 = dataset['GE_9787']
GE_1832 = dataset['GE_1832']
# 200
NMBAC_9787 = dataset['NMBAC_9787']
NMBAC_1832 = dataset['NMBAC_1832']
# 100
PSSM_AB_9787 = dataset['PSSM_AB_9787']
PSSM_AB_1832 = dataset['PSSM_AB_1832']
# 1040
PSSM_DWT_9787 = dataset['PSSM_DWT_9787']
PSSM_DWT_1832 = dataset['PSSM_DWT_1832']
# 180
PSSM_PSE_9787 = dataset['PSSM_PSE_9787']
PSSM_PSE_1832 = dataset['PSSM_PSE_1832']
# 420
reAATP_9787 = dataset_reAATP['reAATP_9787']
reAATP_1832 = dataset_reAATP['reAATP_1832']

# 标签
label_9787 = dataset['label_9787']
label_1832 = dataset['label_1832']

# 拼接
data_train_X = np.concatenate((AATP_9787, GE_9787, NMBAC_9787, PSSM_AB_9787, PSSM_DWT_9787, PSSM_PSE_9787, reAATP_9787),
                              axis=1)
data_train_y = label_9787.ravel()
data_test_X = np.concatenate((AATP_1832, GE_1832, NMBAC_1832, PSSM_AB_1832, PSSM_DWT_1832, PSSM_PSE_1832, reAATP_1832),
                             axis=1)
data_test_y = label_1832.ravel()

data_train_X = np.nan_to_num(data_train_X)
data_train_y = np.nan_to_num(data_train_y)
data_test_X = np.nan_to_num(data_test_X)
data_test_y = np.nan_to_num(data_test_y)

# 不平衡处理
data_train_X, data_train_y = EditedNearestNeighbours().fit_resample(data_train_X, data_train_y)
print(np.sum(data_train_y))

# 归一化
data_train_X, data_test_X = scale_dataset(data_train_X, data_test_X)

# MVEC

multi_views = np.array([
    [1, 420],  # AATP
    #[421, 570],  # GE
    #[571, 770],  # NMBAC
    #[771, 870],  # PSSM_AB
    #[871, 1910],  # PSSM_DWT
    [1911, 2090],  # PSSM_PSE
    #[2091, 2510],  # reAATP

])
dim_views = []  # 每个视角的维数具体有哪些，从0开始
for v in range(len(multi_views)):
    dim_views.extend([i for i in range(multi_views[v][0] - 1, multi_views[v][1])])


# 只取这一部分的话，需要对多视角进行修改
for v in range(len(multi_views)):
    diff = multi_views[v][1]-multi_views[v][0]
    if v==0:
        multi_views[v][0] = 1
        multi_views[v][1] = multi_views[v][0] +diff
    else:
        multi_views[v][0] = multi_views[v-1][1]+1
        multi_views[v][1] = multi_views[v][0] +diff
data_train_X, data_test_X = data_train_X[:, dim_views], data_test_X[:, dim_views]
# data_train_X, data_test_X = MVEC.MVEC(data_train_X, data_test_X, multi_views, M=500, gamma=100, lamda=10)
# data_train_X, data_test_X = union_scale(data_train_X, data_test_X)
data_train_X, data_test_X = scale_dataset(data_train_X, data_test_X)
print(data_train_X.shape)
print(data_test_X.shape)



import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.manifold import TSNE

def t_sne_visualize_3d(train_data, test_data, train_labels, test_labels):
    # t-SNE 降维并可视化
    tsne = TSNE(n_components=3, random_state=3,n_iter=2000,perplexity=40)
    train_tsne = tsne.fit_transform(train_data)
    test_tsne = tsne.fit_transform(test_data)

    # 设置子图
    fig = plt.figure(figsize=(12,6))
    ax1 = fig.add_subplot(121, projection='3d')
    ax1.set_title('Train Data')
    ax2 = fig.add_subplot(122, projection='3d')
    ax2.set_title('Test Data')

    # 绘制散点图
    colors = ['b', 'orange'] # 标签0使用蓝色，标签1使用橙色
    markers = ['o', 's'] # 可以增加更多标记
    size = [1, 2]
    labels = ["Non-vesicular", "Vesicular"]
    for i, label in enumerate(labels):
        mask = (train_labels == i)
        ax1.scatter(train_tsne[mask, 0], train_tsne[mask, 1], train_tsne[mask, 2], s=size[i], c=colors[i], label=label)

    for i, label in enumerate(labels):
        mask = (test_labels == i)
        ax2.scatter(test_tsne[mask, 0], test_tsne[mask, 1], test_tsne[mask, 2], s=size[i], c=colors[i], label=label)

    # 添加图例
    ax1.legend()
    ax2.legend()

    # 显示可视化结果
    plt.show()



def t_sne_visualize(train_data, test_data, train_labels, test_labels):
    # t-SNE 降维并可视化
    
    #tsne = TSNE(n_components=2, random_state=3,init = 'pca',n_iter=1000,perplexity=30)
    tsne = PCA(n_components=2)
    train_tsne = tsne.fit_transform(train_data)
    test_tsne = tsne.fit_transform(test_data)

    # 设置子图
    fig = plt.figure(figsize=(12,6))
    ax1 = fig.add_subplot(121)
    ax1.set_xlim([-2.5, 2.5])
    ax1.set_ylim([-2.0, 2.5])
    ax1.set_title('Train Data')
    ax2 = fig.add_subplot(122)
    ax2.set_xlim([-2.5, 2.5])
    ax2.set_ylim([-2.0, 2.5])
    ax2.set_title('Test Data')

    # 绘制散点图
    colors = ['b', 'red'] # 标签0使用蓝色，标签1使用绿色

    # colors = ['#A1A9D0', '#F0988C', '#B883D4', '#9E9E9E', '#CFEAF1', '#C4A5DE', '#F6CAE5', '#96CCCB']
    # colors = ['#2878b5', '#c82423']
    markers = ['o', 'o'] # 可以增加更多标记
    labels = ["Non-vesicular", "Vesicular"]
    size = [2, 4]
    for i, label in enumerate(labels):
        mask = (train_labels == i)
        ax1.scatter(train_tsne[mask, 0], train_tsne[mask, 1], s=size[i], c=colors[i], marker=markers[i], label=label)

    for i, label in enumerate(labels):
        mask = (test_labels == i)
        ax2.scatter(test_tsne[mask, 0], test_tsne[mask, 1], s=size[i], c=colors[i], marker=markers[i], label=label)

    # 添加图例
    ax1.legend()
    ax2.legend()

    # 显示可视化结果
    plt.tight_layout()
    plt.savefig('Figure5.tif', dpi=1200)
    plt.show()



# 调用函数并传入训练集和测试集的数据和标签
t_sne_visualize(data_train_X, data_test_X, data_train_y, data_test_y)
