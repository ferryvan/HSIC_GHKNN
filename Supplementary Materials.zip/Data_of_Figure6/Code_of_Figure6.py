import os
import random
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve, roc_curve, auc

def read_lists_from_file(filename):
    list1 = []
    list2 = []
    with open(filename, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 2:
                list1.append(float(parts[0]))
                list2.append(float(parts[1]))
    return list1, list2

def plot_pr_curve(ax, filename, label):
    y_true, y_score = read_lists_from_file(filename)
    precision, recall, _ = precision_recall_curve(y_true, y_score)
    ax.plot(recall, precision, label=f"{label}")
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_xlim([min(recall), max(recall)])
    ax.set_ylim([min(precision), max(precision)])
    #ax.set_ylim([0, 1])
    ax.legend()
    ax.set_title("PR Curves")

def plot_roc_curve(ax, filename, label):
    y_true, y_score = read_lists_from_file(filename)
    fpr, tpr, _ = roc_curve(y_true, y_score)
    auc_value = auc(fpr, tpr)
    ax.plot(fpr, tpr, label=f"{label}, AUC = {auc_value:.2f}")
    ax.plot([0, 1], [0, 1], linestyle='--', color='gray')
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_xlim([0, 1])
    ax.set_ylim([0, 1])
    ax.legend()
    ax.set_title("ROC Curves")

# 文件名和显示的标签
filenames = ["KNN.txt", "RF.txt", "SVM.txt", "XGB.txt", "HSIC_GHKNN.txt"]
labels = ["KNN", "RF", "SVM", "XGBoost", "HSIC-GHKNN"]
# colors = ['#A1A9D0', '#F0988C', '#B883D4', '#9E9E9E', '#CFEAF1', '#C4A5DE', '#F6CAE5', '#96CCCB']
# colors = ['#F27970', '#BB9727', '#54B345', '#32B897', '#05B9E2', '#8983BF', '#C76DA2']
# colors = ["r", "g", "b", "c", "m", "y", "k"]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12,6))
for i, filename in enumerate(filenames):
    label = labels[i]
    plot_pr_curve(ax1, filename, label)
    plot_roc_curve(ax2, filename, label)

plt.tight_layout()
plt.savefig('Figure6_2.tif', dpi=1200)
plt.show()